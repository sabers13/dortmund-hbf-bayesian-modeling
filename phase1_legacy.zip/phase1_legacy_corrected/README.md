Phase 1 = legacy corrected version

Purpose
- Preserve the presented approach after debugging and reproducibility fixes.

Main characteristics
- Compares baseline vs hierarchical model structure.
- Uses cleaned continuous predictors: hour_dec, days_until_xmas.
- Includes PPC, LOO, Pareto summaries, trace plots, and sensitivity outputs.
- Uses an audited run output snapshot for freeze reproducibility checks.

Important
- Do not rerun this frozen snapshot after code changes.
- Phase 2 must be developed in a separate folder/branch.

Contents
- src/
- outputs_phase1_legacy_corrected/
- run_command.txt
