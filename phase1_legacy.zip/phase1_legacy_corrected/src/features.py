"""Feature engineering helpers."""
import numpy as np
import pandas as pd


def standardize_series(series):
    mean = series.mean()
    std = series.std(ddof=0)
    if std == 0 or np.isnan(std):
        std = 1.0
    return (series - mean) / std, float(mean), float(std)


def add_standardized_columns(df, cont_cols):
    scalers = {}
    for col in cont_cols:
        _, mean, std = standardize_series(df[col].astype(float))
        scalers[col] = {"mean": mean, "std": std}
    return apply_standardized_columns(df, scalers), scalers


def apply_top_k(series, categories, other_label="Other"):
    series = series.fillna("Unknown").astype(str)
    keep = [c for c in categories if c != other_label]
    return series.where(series.isin(keep), other_label)


def apply_standardized_columns(df, scalers):
    for col, stats in scalers.items():
        mean = stats["mean"]
        std = stats["std"]
        if std == 0 or np.isnan(std):
            std = 1.0
        df[f"{col}_z"] = (df[col].astype(float) - mean) / std
    return df


def map_top_k(series, k=10, other_label="Other"):
    series = series.fillna("Unknown").astype(str)
    top = series.value_counts().nlargest(k).index.tolist()
    mapped = apply_top_k(series, top, other_label=other_label)
    categories = top + ([other_label] if other_label not in top else [])
    return mapped, categories


def choose_grouping(df, min_count=50):
    candidates = ["train_cat", "train_type"]
    stats = {}
    for col in candidates:
        counts = df[col].fillna("Unknown").value_counts()
        coverage = (counts >= min_count).mean()
        stats[col] = {
            "coverage": float(coverage),
            "min_count": int(counts.min()),
            "n_groups": int(counts.shape[0]),
        }
    best = sorted(
        stats.items(),
        key=lambda x: (-x[1]["coverage"], -x[1]["min_count"], x[1]["n_groups"]),
    )[0][0]
    return best, stats


def encode_categorical(series, categories=None):
    if categories is None:
        cat = pd.Categorical(series)
    else:
        cat = pd.Categorical(series, categories=categories)
    if cat.isna().any():
        raise ValueError("Missing category levels after encoding.")
    return cat.codes, list(cat.categories)


def build_model_data(df, cont_cols, cat_cols, cat_levels=None):
    if cat_levels is None:
        cat_levels = {}
    coords = {
        "obs_id": np.arange(len(df)),
        "cont": cont_cols,
    }
    cat_idx = {}
    for col in cat_cols:
        levels = cat_levels.get(col)
        codes, levels = encode_categorical(df[col], levels)
        cat_idx[col] = codes
        coords[col] = levels
        cat_levels[col] = levels
    z_cols = [f"{c}_z" for c in cont_cols]
    X_cont = df[z_cols].to_numpy()
    return {
        "X_cont": X_cont,
        "cat_idx": cat_idx,
        "coords": coords,
        "cat_levels": cat_levels,
    }
