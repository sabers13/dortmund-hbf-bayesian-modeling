"""Applied Bayesian project package."""
