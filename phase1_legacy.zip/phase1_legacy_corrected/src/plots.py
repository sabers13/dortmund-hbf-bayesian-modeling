"""Plotting and result export helpers."""
import os

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pymc as pm
import arviz as az

from .config import RANDOM_SEED


def save_trace(idata, path, var_names=None, coords=None):
    az.plot_trace(idata, var_names=var_names, coords=coords)
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()


def save_summary(idata, path, var_names=None):
    summary = az.summary(idata, var_names=var_names, round_to=2)
    summary.to_csv(path)
    return summary


def _thin_idata(idata, max_draws):
    if not hasattr(idata, "posterior"):
        return idata
    if "draw" not in idata.posterior.dims:
        return idata
    n_draws = int(idata.posterior.sizes.get("draw", 0))
    if n_draws <= max_draws:
        return idata
    rng = np.random.default_rng(RANDOM_SEED)
    draw_idx = np.sort(rng.choice(n_draws, size=max_draws, replace=False))
    try:
        return idata.isel(draw=draw_idx)
    except Exception:
        return idata


def sample_ppc(model, idata, fast_dev, var_names):
    if fast_dev:
        idata = _thin_idata(idata, max_draws=200)
    with model:
        return pm.sample_posterior_predictive(
            idata, var_names=var_names, random_seed=RANDOM_SEED
        )


def ppc_rate_plot(model, idata, observed, path, title, fast_dev):
    ppc = sample_ppc(model, idata, fast_dev, var_names=["y"])
    y_ppc = ppc.posterior_predictive["y"].values
    rates = y_ppc.mean(axis=2).ravel()
    obs_rate = observed.mean()
    plt.figure()
    plt.hist(rates, bins=30, alpha=0.8, color="cornflowerblue")
    plt.axvline(obs_rate, color="red", linewidth=2, label="Observed")
    plt.title(title)
    plt.xlabel("Predicted rate")
    plt.ylabel("Frequency")
    plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()


def ppc_log_delay_plot(model, idata, observed_log, path, title, fast_dev, max_samples=10000):
    ppc = sample_ppc(model, idata, fast_dev, var_names=["log_delay"])
    pred = ppc.posterior_predictive["log_delay"].values
    pred_flat = np.exp(pred).ravel()
    if pred_flat.size > max_samples:
        idx = np.random.choice(pred_flat.size, max_samples, replace=False)
        pred_flat = pred_flat[idx]
    obs_flat = np.exp(observed_log)
    if obs_flat.size > max_samples:
        idx = np.random.choice(obs_flat.size, max_samples, replace=False)
        obs_flat = obs_flat[idx]
    plt.figure()
    plt.hist(pred_flat, bins=40, alpha=0.6, label="PPC", color="steelblue")
    plt.hist(obs_flat, bins=40, alpha=0.6, label="Observed", color="orange")
    plt.title(title)
    plt.xlabel("Delay minutes")
    plt.ylabel("Count")
    plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()


def prior_rate_plot(model, observed, path, title, fast_dev):
    samples = 200 if fast_dev else 500
    with model:
        prior = pm.sample_prior_predictive(samples=samples, random_seed=RANDOM_SEED, return_inferencedata=False)
    y_prior = prior["y"]
    rates = y_prior.mean(axis=1)
    obs_rate = observed.mean()
    plt.figure()
    plt.hist(rates, bins=30, alpha=0.8, color="gray")
    plt.axvline(obs_rate, color="red", linewidth=2, label="Observed")
    plt.title(title)
    plt.xlabel("Prior predictive rate")
    plt.ylabel("Frequency")
    plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()


def save_loo_results(loo_obj, name, out_dir):
    def _get_any(keys, default=None):
        for key in keys:
            try:
                val = loo_obj[key]
                if val is not None:
                    return val
            except Exception:
                val = getattr(loo_obj, key, None)
                if val is not None:
                    return val
        return default

    def _safe_float(x):
        if x is None:
            return np.nan
        try:
            return float(x)
        except Exception:
            return np.nan

    elpd_loo = _get_any(["elpd_loo"])
    se = _get_any(["se", "elpd_loo_se", "se_elpd_loo"])
    p_loo = _get_any(["p_loo"])
    looic = _get_any(["looic"])
    scale = _get_any(["scale"], default="")

    if looic is None and elpd_loo is not None:
        looic = -2.0 * float(elpd_loo)

    loo_row = {
        "elpd_loo": _safe_float(elpd_loo),
        "se": _safe_float(se),
        "p_loo": _safe_float(p_loo),
        "looic": _safe_float(looic),
        "scale": str(scale),
    }

    pd.DataFrame([loo_row]).to_csv(
        os.path.join(out_dir, f"loo_{name}.csv"),
        index=False,
    )

    pareto = _get_any(["pareto_k"], default=None)
    if pareto is not None:
        try:
            pareto.to_pandas().to_csv(os.path.join(out_dir, f"pareto_k_{name}.csv"))
            pareto_vals = pareto.values.ravel()
        except Exception:
            pareto_vals = np.array(pareto).ravel()
            pd.Series(pareto_vals).to_csv(os.path.join(out_dir, f"pareto_k_{name}.csv"), index=False)

        pareto_summary = pd.Series(
            {
                "n_obs": int(pareto_vals.size),
                "pct_k_gt_0.7": float((pareto_vals > 0.7).mean()),
                "pct_k_gt_1.0": float((pareto_vals > 1.0).mean()),
                "max_k": float(np.nanmax(pareto_vals)),
            }
        )
        pareto_summary.to_csv(os.path.join(out_dir, f"pareto_summary_{name}.csv"))
    else:
        pd.Series({"note": "pareto_k missing. Run az.loo(..., pointwise=True)."}).to_csv(
            os.path.join(out_dir, f"pareto_summary_{name}.csv")
        )
