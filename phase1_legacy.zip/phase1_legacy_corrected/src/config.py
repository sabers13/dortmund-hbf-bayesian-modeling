"""Configuration and defaults."""
import os

RANDOM_SEED = 1234
CONT_COLS = ["hour_dec", "days_until_xmas"]

PRIORS_DEFAULT = {
    "beta_scale": 1.0,
    "cat_scale": 1.0,
    "intercept_scale": 1.5,
    "group_sigma_scale": 0.5,
    "sigma_scale": 1.0,
}

REQUIRED_COLS = [
    "delay_in_min",
    "is_canceled",
    "train_cat",
    "train_type",
    "final_destination_station",
    "hour_dec",
    "weekday",
    "day_of_month",
    "days_until_xmas",
    "arrival_planned_time",
    "arrival_change_time",
    "departure_planned_time",
    "departure_change_time",
]


def default_output_dirs(base_dir):
    return {
        "eda": os.path.join(base_dir, "eda"),
        "models": os.path.join(base_dir, "models"),
        "ppc": os.path.join(base_dir, "ppc"),
        "loo": os.path.join(base_dir, "loo"),
        "tables": os.path.join(base_dir, "tables"),
    }
