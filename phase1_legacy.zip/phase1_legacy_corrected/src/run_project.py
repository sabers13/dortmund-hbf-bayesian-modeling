#!/usr/bin/env python3
"""CLI entrypoint for the Applied Bayesian project."""
import argparse
import sys

from .pipeline import run_pipeline


def main():
    parser = argparse.ArgumentParser(description="Run the Applied Bayesian Final Project pipeline.")
    parser.add_argument("--data", default="Dortmund_HBF_December.csv", help="Path to the CSV dataset.")
    parser.add_argument("--outputs", default="outputs", help="Output base directory.")
    parser.add_argument("--fast", action="store_true", help="Enable FAST_DEV mode (subsample + fewer draws).")
    parser.add_argument("--subsample", type=int, default=None, help="Override subsample size for FAST_DEV.")
    parser.add_argument("--cores", type=int, default=None, help="Number of cores for sampling.")
    parser.add_argument("--draws", type=int, default=None, help="Number of posterior draws.")
    parser.add_argument("--tune", type=int, default=None, help="Number of tuning steps.")
    parser.add_argument("--chains", type=int, default=None, help="Number of chains.")
    parser.add_argument("--target-accept", type=float, default=None, help="Target accept probability.")
    args = parser.parse_args()

    run_pipeline(
        data_path=args.data,
        outputs_base=args.outputs,
        fast_dev=args.fast,
        subsample_n=args.subsample,
        cores=args.cores,
        draws=args.draws,
        tune=args.tune,
        chains=args.chains,
        target_accept=args.target_accept,
    )


if __name__ == "__main__":
    sys.exit(main())
