"""End-to-end pipeline for the Applied Bayesian project."""
import json
import os
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import arviz as az

from .config import RANDOM_SEED, CONT_COLS, PRIORS_DEFAULT, default_output_dirs
from .data import load_dataset, validate_and_prepare, clean_data
from .features import (
    add_standardized_columns,
    apply_top_k,
    map_top_k,
    choose_grouping,
    build_model_data,
)
from .models import (
    build_logistic_model,
    build_log_normal_model,
    maybe_subsample,
    sample_model,
    posterior_rate_from_intercept,
)
from .plots import (
    save_trace,
    save_summary,
    ppc_rate_plot,
    ppc_log_delay_plot,
    prior_rate_plot,
    save_loo_results,
)


def run_pipeline(
    data_path,
    outputs_base,
    fast_dev=False,
    subsample_n=None,
    cores=None,
    draws=None,
    tune=None,
    chains=None,
    target_accept=None,
):
    warnings.filterwarnings("ignore", category=FutureWarning)
    np.random.seed(RANDOM_SEED)

    run_tag = "fast" if fast_dev else "full"
    cpu_count = os.cpu_count() or 2
    if cores is None:
        cores = 2 if fast_dev else min(4, cpu_count)

    output_dirs = default_output_dirs(outputs_base)
    for path in output_dirs.values():
        os.makedirs(path, exist_ok=True)

    plt.rcParams.update({
        "figure.figsize": (8, 5),
        "axes.titlesize": 12,
        "axes.labelsize": 11,
    })

    df = load_dataset(data_path)
    print("Raw shape:", df.shape)

    df = validate_and_prepare(df)
    clean_df = clean_data(df)
    print("Clean shape:", clean_df.shape)

    def logit(p):
        return np.log(p / (1 - p))

    priors_story1 = {
        "beta_scale": 0.5,
        "cat_scale": 0.5,
        "intercept_loc": logit(0.10),
        "intercept_scale": 0.7,
        "group_sigma_scale": 0.35,
        "sigma_scale": 1.0,
    }

    priors_story2_delay = {
        "beta_scale": 0.5,
        "cat_scale": 0.5,
        "intercept_loc": logit(0.80),
        "intercept_scale": 0.7,
        "group_sigma_scale": 0.35,
        "sigma_scale": 1.0,
    }

    priors_story3_delay = {
        "beta_scale": 0.5,
        "cat_scale": 0.5,
        "intercept_loc": logit(0.70),
        "intercept_scale": 0.7,
        "group_sigma_scale": 0.35,
        "sigma_scale": 1.0,
    }

    # EDA outputs
    eda_summary = clean_df[["delay_in_min", "is_canceled", "is_delayed"]].describe()
    eda_summary.to_csv(os.path.join(output_dirs["tables"], "eda_summary.csv"))

    cancel_by_weekday = clean_df.groupby("weekday")["is_canceled"].mean().sort_index()
    plt.figure()
    plt.bar(cancel_by_weekday.index.astype(str), cancel_by_weekday.values)
    plt.title("Cancellation rate by weekday")
    plt.xlabel("Weekday")
    plt.ylabel("Cancellation rate")
    plt.tight_layout()
    plt.savefig(os.path.join(output_dirs["eda"], "cancel_rate_by_weekday.png"), dpi=150)
    plt.close()

    pos_delays = clean_df.loc[clean_df["delay_in_min"] > 0, "delay_in_min"]
    plt.figure()
    plt.hist(np.log1p(pos_delays), bins=40, color="steelblue", alpha=0.8)
    plt.title("Positive delays (log1p minutes)")
    plt.xlabel("log1p(delay_in_min)")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(os.path.join(output_dirs["eda"], "delay_distribution_log1p.png"), dpi=150)
    plt.close()

    dest_counts = clean_df["final_destination_station"].value_counts().head(10)
    plt.figure()
    plt.barh(dest_counts.index[::-1], dest_counts.values[::-1], color="slategray")
    plt.title("Top 10 destination stations")
    plt.xlabel("Count")
    plt.tight_layout()
    plt.savefig(os.path.join(output_dirs["eda"], "top_destinations.png"), dpi=150)
    plt.close()

    cancel_by_cat = clean_df.groupby("train_cat")["is_canceled"].mean().sort_values(ascending=False)
    plt.figure()
    plt.barh(cancel_by_cat.index[:12][::-1], cancel_by_cat.values[:12][::-1], color="teal")
    plt.title("Cancellation rate by train_cat (top 12)")
    plt.xlabel("Cancellation rate")
    plt.tight_layout()
    plt.savefig(os.path.join(output_dirs["eda"], "cancel_rate_by_train_cat.png"), dpi=150)
    plt.close()

    print("EDA outputs saved to", output_dirs["eda"])

    if subsample_n is None and fast_dev:
        subsample_n = 6000

    # Story 1: Cancellations
    story1_full = clean_df.copy()
    _, dest_top_levels_1 = map_top_k(story1_full["final_destination_station"], k=10)
    story1_full["dest_top"] = apply_top_k(
        story1_full["final_destination_station"],
        dest_top_levels_1,
    )
    story1_full, _ = add_standardized_columns(story1_full, CONT_COLS)
    story1_full["weekday_cat"] = story1_full["weekday"].astype(int).astype(str)

    group_col_1, group_stats_1 = choose_grouping(story1_full)
    print("Story 1 grouping:", group_col_1, group_stats_1)
    story1_df = maybe_subsample(story1_full, "Story 1", subsample_n if fast_dev else None)

    cat_cols_1 = ["weekday_cat", "dest_top", group_col_1]
    data_1 = build_model_data(story1_df, CONT_COLS, cat_cols_1)
    y_1 = story1_df["is_canceled"].values

    model_1a = build_logistic_model(
        data_1,
        y_1,
        cat_cols=cat_cols_1,
        group_col=group_col_1,
        hierarchical=False,
        priors=priors_story1,
    )
    model_1b = build_logistic_model(
        data_1,
        y_1,
        cat_cols=cat_cols_1,
        group_col=group_col_1,
        hierarchical=True,
        priors=priors_story1,
    )

    idata_1a = sample_model(
        model_1a, "story1_1A", run_tag, output_dirs["models"], fast_dev, cores, draws, tune, chains, target_accept
    )
    idata_1b = sample_model(
        model_1b, "story1_1B", run_tag, output_dirs["models"], fast_dev, cores, draws, tune, chains, target_accept
    )

    # Story 2: Arrival delays
    story2_full = clean_df[(clean_df["is_canceled"] == 0) & (clean_df["arrival_planned_time"].notna())].copy()
    _, dest_top_levels_2 = map_top_k(story2_full["final_destination_station"], k=10)
    story2_full["dest_top"] = apply_top_k(
        story2_full["final_destination_station"],
        dest_top_levels_2,
    )
    story2_full, _ = add_standardized_columns(story2_full, CONT_COLS)
    story2_full["weekday_cat"] = story2_full["weekday"].astype(int).astype(str)

    group_col_2, group_stats_2 = choose_grouping(story2_full)
    print("Story 2 grouping:", group_col_2, group_stats_2)
    story2_df = maybe_subsample(story2_full, "Story 2 (arrival)", subsample_n if fast_dev else None)

    cat_cols_2 = ["weekday_cat", "dest_top", group_col_2]

    data_2a = build_model_data(story2_df, CONT_COLS, cat_cols_2)
    y_2a = story2_df["is_delayed"].values

    model_2a_delay = build_logistic_model(
        data_2a,
        y_2a,
        cat_cols=cat_cols_2,
        group_col=group_col_2,
        hierarchical=False,
        priors=priors_story2_delay,
    )
    model_2b_delay = build_logistic_model(
        data_2a,
        y_2a,
        cat_cols=cat_cols_2,
        group_col=group_col_2,
        hierarchical=True,
        priors=priors_story2_delay,
    )

    idata_2a_delay = sample_model(
        model_2a_delay, "story2_2A_delay", run_tag, output_dirs["models"], fast_dev, cores, draws, tune, chains, target_accept
    )
    idata_2b_delay = sample_model(
        model_2b_delay, "story2_2B_delay", run_tag, output_dirs["models"], fast_dev, cores, draws, tune, chains, target_accept
    )

    story2_pos = story2_df[story2_df["delay_in_min"] > 0].copy()
    story2_pos = maybe_subsample(
        story2_pos,
        "Story 2 (arrival positive delays)",
        subsample_n if fast_dev else None,
    )

    cat_levels_2 = data_2a["cat_levels"]
    data_2b = build_model_data(story2_pos, CONT_COLS, cat_cols_2, cat_levels=cat_levels_2)

    y_2b_log = np.log(story2_pos["delay_in_min"].values)

    model_2a_log = build_log_normal_model(data_2b, y_2b_log, cat_cols=cat_cols_2, group_col=group_col_2, hierarchical=False)
    model_2b_log = build_log_normal_model(data_2b, y_2b_log, cat_cols=cat_cols_2, group_col=group_col_2, hierarchical=True)

    idata_2a_log = sample_model(
        model_2a_log, "story2_2A_log", run_tag, output_dirs["models"], fast_dev, cores, draws, tune, chains, target_accept
    )
    idata_2b_log = sample_model(
        model_2b_log, "story2_2B_log", run_tag, output_dirs["models"], fast_dev, cores, draws, tune, chains, target_accept
    )

    # Story 3: Departure delays
    story3_full = clean_df[(clean_df["is_canceled"] == 0) & (clean_df["departure_planned_time"].notna())].copy()
    _, dest_top_levels_3 = map_top_k(story3_full["final_destination_station"], k=10)
    story3_full["dest_top"] = apply_top_k(
        story3_full["final_destination_station"],
        dest_top_levels_3,
    )
    story3_full, _ = add_standardized_columns(story3_full, CONT_COLS)
    story3_full["weekday_cat"] = story3_full["weekday"].astype(int).astype(str)

    group_col_3, group_stats_3 = choose_grouping(story3_full)
    print("Story 3 grouping:", group_col_3, group_stats_3)
    story3_df = maybe_subsample(story3_full, "Story 3 (departure)", subsample_n if fast_dev else None)

    cat_cols_3 = ["weekday_cat", "dest_top", group_col_3]

    data_3a = build_model_data(story3_df, CONT_COLS, cat_cols_3)
    y_3a = story3_df["is_delayed"].values

    model_3a_delay = build_logistic_model(
        data_3a,
        y_3a,
        cat_cols=cat_cols_3,
        group_col=group_col_3,
        hierarchical=False,
        priors=priors_story3_delay,
    )
    model_3b_delay = build_logistic_model(
        data_3a,
        y_3a,
        cat_cols=cat_cols_3,
        group_col=group_col_3,
        hierarchical=True,
        priors=priors_story3_delay,
    )

    idata_3a_delay = sample_model(
        model_3a_delay, "story3_3A_delay", run_tag, output_dirs["models"], fast_dev, cores, draws, tune, chains, target_accept
    )
    idata_3b_delay = sample_model(
        model_3b_delay, "story3_3B_delay", run_tag, output_dirs["models"], fast_dev, cores, draws, tune, chains, target_accept
    )

    story3_pos = story3_df[story3_df["delay_in_min"] > 0].copy()
    story3_pos = maybe_subsample(
        story3_pos,
        "Story 3 (departure positive delays)",
        subsample_n if fast_dev else None,
    )

    cat_levels_3 = data_3a["cat_levels"]
    data_3b = build_model_data(story3_pos, CONT_COLS, cat_cols_3, cat_levels=cat_levels_3)

    y_3b_log = np.log(story3_pos["delay_in_min"].values)

    model_3a_log = build_log_normal_model(data_3b, y_3b_log, cat_cols=cat_cols_3, group_col=group_col_3, hierarchical=False)
    model_3b_log = build_log_normal_model(data_3b, y_3b_log, cat_cols=cat_cols_3, group_col=group_col_3, hierarchical=True)

    idata_3a_log = sample_model(
        model_3a_log, "story3_3A_log", run_tag, output_dirs["models"], fast_dev, cores, draws, tune, chains, target_accept
    )
    idata_3b_log = sample_model(
        model_3b_log, "story3_3B_log", run_tag, output_dirs["models"], fast_dev, cores, draws, tune, chains, target_accept
    )

    # Diagnostics & PPC
    model_registry = {
        "1A": {"model": model_1a, "idata": idata_1a, "kind": "bernoulli", "obs": y_1},
        "1B": {"model": model_1b, "idata": idata_1b, "kind": "bernoulli", "obs": y_1},
        "2A_delay": {"model": model_2a_delay, "idata": idata_2a_delay, "kind": "bernoulli", "obs": y_2a},
        "2B_delay": {"model": model_2b_delay, "idata": idata_2b_delay, "kind": "bernoulli", "obs": y_2a},
        "2A_log": {"model": model_2a_log, "idata": idata_2a_log, "kind": "log_delay", "obs": y_2b_log},
        "2B_log": {"model": model_2b_log, "idata": idata_2b_log, "kind": "log_delay", "obs": y_2b_log},
        "3A_delay": {"model": model_3a_delay, "idata": idata_3a_delay, "kind": "bernoulli", "obs": y_3a},
        "3B_delay": {"model": model_3b_delay, "idata": idata_3b_delay, "kind": "bernoulli", "obs": y_3a},
        "3A_log": {"model": model_3a_log, "idata": idata_3a_log, "kind": "log_delay", "obs": y_3b_log},
        "3B_log": {"model": model_3b_log, "idata": idata_3b_log, "kind": "log_delay", "obs": y_3b_log},
    }

    # LOO per model
    loo_objects = {}
    for name, info in model_registry.items():
        try:
            loo_obj = az.loo(info["idata"], pointwise=True)
            loo_objects[name] = loo_obj
            save_loo_results(loo_obj, name, output_dirs["loo"])
        except Exception as e:
            pd.DataFrame(
                [{"model": name, "error": str(e)}]
            ).to_csv(
                os.path.join(output_dirs["loo"], f"loo_{name}_error.csv"),
                index=False,
            )

    # LOO comparisons for the main model pairs
    loo_pairs = [
        ("story1_compare", ["1A", "1B"]),
        ("story2_delay_compare", ["2A_delay", "2B_delay"]),
        ("story2_log_compare", ["2A_log", "2B_log"]),
        ("story3_delay_compare", ["3A_delay", "3B_delay"]),
        ("story3_log_compare", ["3A_log", "3B_log"]),
    ]

    for table_name, model_names in loo_pairs:
        try:
            comp = az.compare(
                {m: loo_objects[m] for m in model_names},
                method="stacking",
            )
            comp.to_csv(os.path.join(output_dirs["loo"], f"{table_name}.csv"))
        except Exception as e:
            pd.DataFrame(
                [{"comparison": table_name, "error": str(e)}]
            ).to_csv(
                os.path.join(output_dirs["loo"], f"{table_name}_error.csv"),
                index=False,
            )

    summary_rows = []
    for name, info in model_registry.items():
        summary_path = os.path.join(output_dirs["tables"], f"summary_{name}.csv")
        save_summary(info["idata"], summary_path)

        divergences = int(info["idata"].sample_stats["diverging"].sum())
        summary_rows.append({"model": name, "divergences": divergences})

    summary_df = pd.DataFrame(summary_rows)
    summary_df.to_csv(os.path.join(output_dirs["tables"], "divergences_summary.csv"), index=False)

    save_summary(
        idata_1b,
        os.path.join(output_dirs["tables"], f"summary_1B_{group_col_1}_effects.csv"),
        var_names=[f"{group_col_1}_sigma", f"{group_col_1}_eff"],
    )

    save_summary(
        idata_2b_delay,
        os.path.join(output_dirs["tables"], f"summary_2B_delay_{group_col_2}_effects.csv"),
        var_names=[f"{group_col_2}_sigma", f"{group_col_2}_eff"],
    )

    save_summary(
        idata_2b_log,
        os.path.join(output_dirs["tables"], f"summary_2B_log_{group_col_2}_effects.csv"),
        var_names=[f"{group_col_2}_sigma", f"{group_col_2}_eff"],
    )

    save_summary(
        idata_3b_delay,
        os.path.join(output_dirs["tables"], f"summary_3B_delay_{group_col_3}_effects.csv"),
        var_names=[f"{group_col_3}_sigma", f"{group_col_3}_eff"],
    )

    save_summary(
        idata_3b_log,
        os.path.join(output_dirs["tables"], f"summary_3B_log_{group_col_3}_effects.csv"),
        var_names=[f"{group_col_3}_sigma", f"{group_col_3}_eff"],
    )

    # Trace plots: one clean scalar beta per continuous predictor
    for cont_name in CONT_COLS:
        save_trace(
            idata_1a,
            os.path.join(output_dirs["models"], f"trace_story1_1A_{cont_name}.png"),
            var_names=["intercept", "beta"],
            coords={"cont": [cont_name]},
        )

        save_trace(
            idata_2a_delay,
            os.path.join(output_dirs["models"], f"trace_story2_2A_{cont_name}.png"),
            var_names=["intercept", "beta"],
            coords={"cont": [cont_name]},
        )

        save_trace(
            idata_3a_delay,
            os.path.join(output_dirs["models"], f"trace_story3_3A_{cont_name}.png"),
            var_names=["intercept", "beta"],
            coords={"cont": [cont_name]},
        )

    # Old-style combined beta plots (all beta coordinates together)
    save_trace(
        idata_1a,
        os.path.join(output_dirs["models"], "trace_story1_1A_beta_all.png"),
        var_names=["beta"],
    )

    save_trace(
        idata_2a_delay,
        os.path.join(output_dirs["models"], "trace_story2_2A_beta_all.png"),
        var_names=["beta"],
    )

    save_trace(
        idata_3a_delay,
        os.path.join(output_dirs["models"], "trace_story3_3A_beta_all.png"),
        var_names=["beta"],
    )

    for name, info in model_registry.items():
        path = os.path.join(output_dirs["ppc"], f"ppc_{name}.png")
        if info["kind"] == "bernoulli":
            ppc_rate_plot(info["model"], info["idata"], info["obs"], path, f"PPC rate: {name}", fast_dev)
        else:
            ppc_log_delay_plot(info["model"], info["idata"], info["obs"], path, f"PPC delays: {name}", fast_dev)

    print("Diagnostics and PPC outputs saved.")

    # Prior predictive & sensitivity analysis
    prior_rate_plot(model_1a, y_1, os.path.join(output_dirs["ppc"], "prior_story1_1A.png"), "Prior predictive: Story 1", fast_dev)
    prior_rate_plot(model_2a_delay, y_2a, os.path.join(output_dirs["ppc"], "prior_story2_2A.png"), "Prior predictive: Story 2", fast_dev)
    prior_rate_plot(model_3a_delay, y_3a, os.path.join(output_dirs["ppc"], "prior_story3_3A.png"), "Prior predictive: Story 3", fast_dev)

    priors_wide = {
        "beta_scale": 0.8,
        "cat_scale": 0.8,
        "intercept_loc": logit(0.80),
        "intercept_scale": 1.0,
        "group_sigma_scale": 0.5,
        "sigma_scale": 1.0,
    }

    model_2a_delay_wide = build_logistic_model(
        data_2a,
        y_2a,
        cat_cols=cat_cols_2,
        group_col=group_col_2,
        hierarchical=False,
        priors=priors_wide,
    )

    idata_2a_delay_wide = sample_model(
        model_2a_delay_wide, "story2_2A_wide", run_tag, output_dirs["models"], fast_dev, cores, draws, tune, chains, target_accept
    )

    base_rate = posterior_rate_from_intercept(idata_2a_delay)
    wide_rate = posterior_rate_from_intercept(idata_2a_delay_wide)

    sens_df = pd.DataFrame({
        "model": ["2A_default", "2A_wide"],
        "mean_rate": [base_rate.mean(), wide_rate.mean()],
        "sd_rate": [base_rate.std(), wide_rate.std()],
    })

    sens_df.to_csv(os.path.join(output_dirs["tables"], "sensitivity_story2.csv"), index=False)
    print(sens_df)

    expected_files = []

    # core summaries
    for name in model_registry.keys():
        expected_files.append(os.path.join(output_dirs["tables"], f"summary_{name}.csv"))
        expected_files.append(os.path.join(output_dirs["ppc"], f"ppc_{name}.png"))
        expected_files.append(os.path.join(output_dirs["loo"], f"loo_{name}.csv"))
        expected_files.append(os.path.join(output_dirs["loo"], f"pareto_summary_{name}.csv"))

    # trace plots: one per continuous coefficient
    for cont_name in CONT_COLS:
        expected_files.extend([
            os.path.join(output_dirs["models"], f"trace_story1_1A_{cont_name}.png"),
            os.path.join(output_dirs["models"], f"trace_story2_2A_{cont_name}.png"),
            os.path.join(output_dirs["models"], f"trace_story3_3A_{cont_name}.png"),
        ])

    # old-style combined beta plots
    expected_files.extend([
        os.path.join(output_dirs["models"], "trace_story1_1A_beta_all.png"),
        os.path.join(output_dirs["models"], "trace_story2_2A_beta_all.png"),
        os.path.join(output_dirs["models"], "trace_story3_3A_beta_all.png"),
    ])

    # prior predictive plots
    expected_files.extend([
        os.path.join(output_dirs["ppc"], "prior_story1_1A.png"),
        os.path.join(output_dirs["ppc"], "prior_story2_2A.png"),
        os.path.join(output_dirs["ppc"], "prior_story3_3A.png"),
    ])

    # pairwise LOO comparison tables
    expected_files.extend([
        os.path.join(output_dirs["loo"], "story1_compare.csv"),
        os.path.join(output_dirs["loo"], "story2_delay_compare.csv"),
        os.path.join(output_dirs["loo"], "story2_log_compare.csv"),
        os.path.join(output_dirs["loo"], "story3_delay_compare.csv"),
        os.path.join(output_dirs["loo"], "story3_log_compare.csv"),
    ])

    # hierarchical effect summaries from Step 6
    expected_files.extend([
        os.path.join(output_dirs["tables"], f"summary_1B_{group_col_1}_effects.csv"),
        os.path.join(output_dirs["tables"], f"summary_2B_delay_{group_col_2}_effects.csv"),
        os.path.join(output_dirs["tables"], f"summary_2B_log_{group_col_2}_effects.csv"),
        os.path.join(output_dirs["tables"], f"summary_3B_delay_{group_col_3}_effects.csv"),
        os.path.join(output_dirs["tables"], f"summary_3B_log_{group_col_3}_effects.csv"),
    ])

    missing_files = [p for p in expected_files if not os.path.exists(p)]
    pd.DataFrame({"missing_file": missing_files}).to_csv(
        os.path.join(output_dirs["tables"], "missing_outputs.csv"),
        index=False,
    )

    manifest = {
        "run_tag": run_tag,
        "fast_dev": fast_dev,
        "cont_cols": CONT_COLS,
        "group_col_story1": group_col_1,
        "group_col_story2": group_col_2,
        "group_col_story3": group_col_3,
        "group_stats_story1": group_stats_1,
        "group_stats_story2": group_stats_2,
        "group_stats_story3": group_stats_3,
        "n_models": len(model_registry),
        "n_expected_files": len(expected_files),
        "n_missing_files": len(missing_files),
    }

    with open(os.path.join(output_dirs["tables"], "run_manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)

    print(f"Expected files: {len(expected_files)}")
    print(f"Missing files: {len(missing_files)}")
    if missing_files:
        print("Missing outputs written to:", os.path.join(output_dirs["tables"], "missing_outputs.csv"))
    else:
        print("All expected outputs are present.")
